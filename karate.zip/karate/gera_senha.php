<?php
    $teste = "4321";

    $senha = md5($teste);

    echo "Senha gerada => $senha";

?>